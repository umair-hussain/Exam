package com.example.sp17_bse_021_assi2;

import android.annotation.SuppressLint;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;


/**
 * A simple {@link Fragment} subclass.
 */
public class Animation extends Fragment {
    private SharedView model;
    AnimationDrawable animation;
    ImageView image;

    ImageView playerImage;
    int[] images = new int[5];



    public Animation() {
        // Required empty public constructor
    }



    @SuppressLint("FragmentLiveDataObserve")
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        //Creating observer for position change using getPos method of SharedViewModel
         model = ViewModelProviders.of(requireActivity()).get(SharedView.class);


         image = (ImageView) getActivity().findViewById(R.id.playerimg);
        image.setBackgroundResource(R.drawable.idle_anim);
        animation = (AnimationDrawable) image.getBackground();

        animation.start();

        model.getPos().observe(this, new Observer<String>() {
            //when the value of data changed
            @Override
            public void onChanged(String anim) {
                setimage(anim);
            }
        });
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_animation, container, false);
    }



    public void setimage(String anim) {

        images[0] = R.drawable.idle_anim;
        images[1] = R.drawable.attact_anim;
        images[2] = R.drawable.crouch_anim;
        images[3] = R.drawable.jump_anim;
        images[4] = R.drawable.run_anim;
            if (anim.equalsIgnoreCase("idle"))
            {
                image.setBackgroundResource(images[0]);
            }
            else if  (anim.equalsIgnoreCase("attack"))
            {
                image.setBackgroundResource(images[1]);
            }
            else if  (anim.equalsIgnoreCase("crouch"))
            {
                image.setBackgroundResource(images[2]);
            }
            else if  (anim.equalsIgnoreCase("jump"))
            {
                image.setBackgroundResource(images[3]);
            }
            else if  (anim.equalsIgnoreCase("run"))
            {
                image.setBackgroundResource(images[4]);
            }

        animation = (AnimationDrawable) image.getBackground();

        animation.start();



   }

}
