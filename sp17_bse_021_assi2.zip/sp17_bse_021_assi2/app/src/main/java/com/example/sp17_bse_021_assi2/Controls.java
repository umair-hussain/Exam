package com.example.sp17_bse_021_assi2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;


/**
 * A simple {@link Fragment} subclass.
 */
public class Controls extends Fragment {


    private SharedView model;
    public Controls() {
        // Required empty public constructor

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_control, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
       // sending the item click position to sendPosToMF method of SharedViewModel Class
        model = ViewModelProviders.of(getActivity()).get(SharedView.class);
        Button idlebutton =getActivity().findViewById(R.id.idlebtn);
        Button jumpbutton =getActivity().findViewById(R.id.jumpbtn);
        Button attacButton =getActivity().findViewById(R.id.attackbtn);
        Button runbutton =getActivity().findViewById(R.id.runbtn);
        Button crouchbutton =getActivity().findViewById(R.id.crouchbtn);

        idlebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                model.sendPosToMF("idle");
            }
        });

        jumpbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                model.sendPosToMF("jump");
            }
        });

        attacButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                model.sendPosToMF("attack");
            }
        });

        runbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                model.sendPosToMF("run");
            }
        });

        crouchbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                model.sendPosToMF("crouch");
            }
        });




    }


}
