package com.example.sp17_bse_021_assi2;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SharedView extends ViewModel {

    private MutableLiveData<String> pos;
    public void init()
    {
        pos = new MutableLiveData<>();
        pos.setValue("idle");
    }
    public void sendPosToMF(String anim)
    {
        pos.setValue(anim);
    }

    public LiveData<String> getPos() {

        return pos;
    }
}
