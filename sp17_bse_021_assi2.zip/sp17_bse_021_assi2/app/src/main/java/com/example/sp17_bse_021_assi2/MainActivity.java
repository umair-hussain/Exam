package com.example.sp17_bse_021_assi2;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

public class MainActivity extends AppCompatActivity {

    AnimationDrawable rocketAnimation;

    private SharedView viewModel ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ImageView rocketImage = (ImageView) findViewById(R.id.image);
//         rocketImage.setBackgroundResource(R.drawable.idle_anim);
//        rocketAnimation = (AnimationDrawable) rocketImage.getBackground();

        viewModel = ViewModelProviders.of(this).get(SharedView.class);
        viewModel.init();
    }

    }





