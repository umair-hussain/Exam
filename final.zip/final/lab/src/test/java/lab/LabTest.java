package lab;

public class LabTest {

}
