package pk.cui.sc.exam;


    import java.time.LocalDate;
	import java.time.ZoneId;
	import java.util.Date;
	
	public class Lab {
	static Date today = new Date();
	/* convert fahrenheitToCentigrade
	  */
	public static int fahrenheitToCentigrade(int fahrenheit) {
	return (fahrenheit - 32) * 5 / 9;
	}
	/* convert centigradeToFahrenheit
	  */
	public static int centigradeToFahrenheit(int centigrade) {
	return centigrade * 9 / 5 + 32;
	}
	/* remove Sign Of Exclaimation
	  */
	public static String removeSignOfExclaimation(String in){
	if(in==null||in.length()==0)
	return in;
	return in.replaceAll("!", "");
	}
	/* get current day
	  */
	public static int getCurrentDay(){
	LocalDate localDate = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	return localDate.getDayOfMonth();
	}
	/* get current month
	  */
	
	public static int getCurrentMonth(){
	LocalDate localDate = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	return localDate.getMonthValue();
	}
	/* get current year
	  */
	public static int getCurrentYear(){
	LocalDate localDate = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	return localDate.getYear();
	}
	}


